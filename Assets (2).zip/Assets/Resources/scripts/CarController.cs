using System;
using System.Collections.Generic;
using UnityEngine;

namespace CarContollingScripts
{
    public class CarController : MonoBehaviour
    {
        public enum ControlMode
        {
            Keyboard,
            Buttons
        }

        public enum Axel
        {
            Front,
            Rear
        }

        [Serializable]
        public struct Wheel
        {
            public GameObject wheelModel;
            public WheelCollider wheelCollider;
            public Axel axel;
            public TrailRenderer trailRenderer;
        }

        [Header("Control")]
        public ControlMode control = ControlMode.Keyboard;

        [Header("Engine")]
        public float maxAcceleration = 30f;
        public float maxSpeed = 40f;
        public float reverseSpeed = 10f;
        public float minimumDrivingSpeed = 10f;
        public bool maintainMinimumSpeed = false;
        public float brakeAcceleration = 50f;

        [Header("Steering")]
        public float turnSensitivity = 1f;
        public float maxSteerAngle = 30f;
        public float backwheelturn = 2f;
        public float steeringSmoothness = 5f;
        public float highSpeedSteeringReduction = 0.45f;

        [Header("Drifting")]
        public bool enableDrifting = true;
        public float driftStartSpeed = 15f;
        [Range(0.1f, 1f)]
        public float rearDriftGrip = 0.65f;
        public float driftGripTransition = 4f;
        public float driftSteeringAssist = 0.5f;

        [Header("Auto Drift")]
        public bool autoAccelerate = true;
        public bool autoDrift = true;
        [Range(0.1f, 1f)] public float autoDriftEnterSteer = 0.65f; // |steer| needed to start drifting
        [Range(0.05f, 1f)] public float autoDriftExitSteer = 0.35f; // |steer| below this ends the drift
        public float autoDriftMinSpeed = 30f;                       // km/h to start
        public float autoDriftExitSpeed = 18f;                      // km/h to stop
        public float maxDriftAngle = 50f;                           // degrees, grip returns above this
        public float counterSteerAssist = 0.6f;                     // automatic counter-steer
        public float alignStrength = 4f;                            // self-straightening force

        private bool autoDrifting;
        private float slipAngle; // degrees, + = velocity points to the right of the car
        [Header("Stability")]
        public Vector3 _centerOfMass = new Vector3(0f, -0.4f, 0f);
        public float downforce = 30f;
        public float lateralGrip = 1.5f;
        public float stabilityStrength = 2f;
        [Header("Scoring")]
        public float score;
        public float multiplier = 1f;
        public float driftSteerThreshold = 15f;  // |currentSteer| above this counts as a drift
        public float scorePerSecond = 20f;       // base points per second while drifting
        public float multiplierRamp = 0.6f;      // higher = multiplier grows faster
        public float maxMultiplier = 20f;
        public float driftGraceTime = 0.35f;     // seconds you can dip below the threshold without losing the streak

        float driftHoldTime;
        float graceTimer;

        [Header("Wheel Setup")]
        public List<Wheel> wheels = new List<Wheel>();
        public Transform body;

        private Rigidbody carRb;

        private float moveInput;
        private float steerInput;
        private float currentSteer;
        private bool isBraking;
        private float mobilesteer;

        private float driftAmount;
        private WheelFrictionCurve[] originalSidewaysFriction;

        public float SlipAngle => slipAngle;
        public float DriftAmount => driftAmount;
        public bool IsDrifting => enableDrifting && (autoDrifting || driftAmount > 0.05f);

        void Start()
        {
            carRb = GetComponent<Rigidbody>();

            if (carRb == null)
            {
                Debug.LogError("CarController requires a Rigidbody.", this);
                enabled = false;
                return;
            }

            carRb.centerOfMass = _centerOfMass;

            originalSidewaysFriction =
                new WheelFrictionCurve[wheels.Count];

            for (int i = 0; i < wheels.Count; i++)
            {
                Wheel wheel = wheels[i];

                if (wheel.wheelCollider != null)
                {
                    originalSidewaysFriction[i] =
                        wheel.wheelCollider.sidewaysFriction;
                }

                if (wheel.trailRenderer != null)
                {
                    wheel.trailRenderer.emitting = false;
                }
            }
        }
        private void Awake()
        {
            Application.targetFrameRate = 60;
        }
        void Update()
        {
            GetInputs();
            AnimateWheels();
            WheelEffects();
        }

        void FixedUpdate()
        {
            if (carRb == null) return;

            UpdateSlipAndDriftState();
            Move();
            Steer();
            Brake();
            ApplyStability();
            UpdateDriftGrip();
            print(score);
            UpdateScore(Time.fixedDeltaTime);
        }

        void UpdateSlipAndDriftState()
        {
            Vector3 vel = carRb.linearVelocity; vel.y = 0f;
            float speedKmh = vel.magnitude * 3.6f;
            float fwd = Vector3.Dot(vel, transform.forward);

            if (speedKmh > 5f && fwd > 0f)
                slipAngle = Vector3.SignedAngle(
                    Vector3.ProjectOnPlane(transform.forward, Vector3.up),
                    vel, Vector3.up);
            else
                slipAngle = 0f;

            float s = Mathf.Abs(steerInput);
            if (!autoDrifting && autoDrift && s >= autoDriftEnterSteer && speedKmh >= autoDriftMinSpeed)
                autoDrifting = true;
            else if (autoDrifting && (s < autoDriftExitSteer || speedKmh < autoDriftExitSpeed))
                autoDrifting = false;
        }

        public void MoveInput(float input)
        {
            moveInput = Mathf.Clamp(input, -1f, 1f);
        }

        public void SteerInput(float input)
        {
            steerInput = Mathf.Clamp(input, -1f, 1f);
        }

        public void BrakeInput(bool input)
        {
            isBraking = input;
        }

        void GetInputs()
        {
            if (control == ControlMode.Keyboard)
            {

                steerInput = Input.GetAxis("Horizontal");


            }
            // Buttons mode uses the public input methods above.

        }





        void Move()
        {
            float forwardSpeed =
                Vector3.Dot(carRb.linearVelocity, transform.forward) * 3.6f;

            float speed = carRb.linearVelocity.magnitude * 3.6f;

            bool reversing = 1 < -0.05f;

            for (int i = 0; i < wheels.Count; i++)
            {
                Wheel wheel = wheels[i];

                if (wheel.wheelCollider == null) continue;

                WheelCollider collider = wheel.wheelCollider;

                collider.motorTorque = 0f;

                // Apply drive torque only when the car can accelerate
                // in the requested direction.
                if (isBraking) continue;

                if (reversing)
                {
                    if (forwardSpeed > 1f) continue;

                    if (forwardSpeed > -reverseSpeed)
                    {
                        collider.motorTorque =
                            1 * maxAcceleration * 100f;
                    }
                }
                else if (1 > 0.05f)
                {
                    if (forwardSpeed < maxSpeed)
                    {
                        float acceleration = maxAcceleration;

                        // Optional minimum driving speed while throttle
                        // is held. This is a soft acceleration assist.
                        if (maintainMinimumSpeed &&
                            forwardSpeed >= 0f &&
                            forwardSpeed < minimumDrivingSpeed)
                        {
                            acceleration *= 1.5f;
                        }

                        collider.motorTorque =
                            1 * acceleration * 100f;
                    }
                }
            }

            // Smoothly prevent excessive forward and reverse speed.
            if (forwardSpeed > maxSpeed)
            {
                carRb.AddForce(
                    -transform.forward *
                    ((forwardSpeed - maxSpeed) * 0.5f),
                    ForceMode.Acceleration);
            }
            else if (forwardSpeed < -reverseSpeed)
            {
                carRb.AddForce(
                    transform.forward *
                    ((-reverseSpeed - forwardSpeed) * 0.5f),
                    ForceMode.Acceleration);
            }
        }

        void Steer()
        {
            float speed = carRb.linearVelocity.magnitude * 3.6f;

            // Reduce steering sensitivity at higher speeds.
            float speedFactor = Mathf.Lerp(
                1f,
                highSpeedSteeringReduction,
                Mathf.InverseLerp(10f, maxSpeed, speed));

            float targetSteer =
                steerInput * turnSensitivity *
                maxSteerAngle * speedFactor;



            // Counter-steer toward the direction of travel while sliding
            targetSteer += slipAngle * counterSteerAssist * driftAmount;
            targetSteer = Mathf.Clamp(targetSteer, -maxSteerAngle, maxSteerAngle);

            currentSteer = Mathf.Lerp(
                currentSteer,
                targetSteer,
                1f - Mathf.Exp(-steeringSmoothness *
                               Time.fixedDeltaTime));

            for (int i = 0; i < wheels.Count; i++)
            {
                Wheel wheel = wheels[i];

                if (wheel.wheelCollider == null) continue;

                float angle;

                if (wheel.axel == Axel.Front)
                {
                    angle = currentSteer;
                }
                else
                {
                    // Counter-steer rear wheels gently for stability.
                    angle = -currentSteer /
                            Mathf.Max(1f, backwheelturn);

                    // Reduce rear steering when moving quickly.
                    angle *= 1f - driftAmount * driftSteeringAssist;

                }

                wheel.wheelCollider.steerAngle = angle;
            }
        }

        void UpdateScore(float dt)
        {
            float steerAmount = Mathf.Abs(currentSteer);
            bool drifting = steerAmount > driftSteerThreshold;

            if (drifting)
            {
                driftHoldTime += dt;
                graceTimer = driftGraceTime;
            }
            else
            {
                graceTimer -= dt;
                if (graceTimer <= 0f) driftHoldTime = 0f;   // streak lost
            }

            // Quadratic growth: slow at first, then it explodes the longer you hold
            multiplier = Mathf.Min(maxMultiplier, 1f + multiplierRamp * driftHoldTime * driftHoldTime);

            if (drifting)
                score += scorePerSecond * multiplier * dt;
        }

        void Brake()
        {
            float speed = carRb.linearVelocity.magnitude * 3.6f;

            for (int i = 0; i < wheels.Count; i++)
            {
                Wheel wheel = wheels[i];

                if (wheel.wheelCollider == null) continue;

                // Always reset brake torque when not braking.
                if (!isBraking)
                {
                    wheel.wheelCollider.brakeTorque = 0f;
                    continue;
                }

                float brakePower = brakeAcceleration * 100f;

                // Rear braking helps initiate a drift.
                if (enableDrifting &&
                    speed >= driftStartSpeed &&
                    wheel.axel == Axel.Rear)
                {
                    brakePower *= 1.25f;
                }

                wheel.wheelCollider.brakeTorque = brakePower;
            }
        }

        void UpdateDriftGrip()
        {
            float targetDrift = 0f;

            if (enableDrifting && (autoDrifting || (isBraking && carRb.linearVelocity.magnitude * 3.6f >= driftStartSpeed)))

            {
                targetDrift = 1f;


                // Anti-spin: grip comes back as the slide angle approaches the limit
                float angleFactor = 1f - Mathf.InverseLerp(maxDriftAngle * 0.8f, maxDriftAngle * 1.2f, Mathf.Abs(slipAngle));
                targetDrift *= angleFactor;
            }

            driftAmount = Mathf.MoveTowards(driftAmount, targetDrift, driftGripTransition * Time.fixedDeltaTime);

            for (int i = 0; i < wheels.Count; i++)
            {
                Wheel wheel = wheels[i];
                if (wheel.wheelCollider == null) continue;

                WheelFrictionCurve friction = originalSidewaysFriction[i];
                if (wheel.axel == Axel.Rear && enableDrifting)
                {
                    friction.stiffness = originalSidewaysFriction[i].stiffness *
                                         Mathf.Lerp(1f, rearDriftGrip, driftAmount);
                }
                wheel.wheelCollider.sidewaysFriction = friction;
            }
        }
        void ApplyStability()
        {
            float speed = carRb.linearVelocity.magnitude;

            // Downforce keeps the car planted at speed.
            carRb.AddForce(
                -transform.up * downforce * speed,
                ForceMode.Force);

            // Dampen unwanted sideways motion without removing
            // all lateral velocity needed for drifting.
            Vector3 localVelocity =
                transform.InverseTransformDirection(carRb.linearVelocity);

            float grip = lateralGrip;

            if (enableDrifting)
            {
                grip *= Mathf.Lerp(1f, 0.35f, driftAmount);
            }

            Vector3 correction =
                -transform.right * localVelocity.x * grip;

            carRb.AddForce(correction, ForceMode.Acceleration);

            // Mildly resist unwanted yaw spin at higher speeds.
            Vector3 localAngularVelocity =
                transform.InverseTransformDirection(carRb.angularVelocity);

            float yawDamping = stabilityStrength *
                               Mathf.Lerp(0.5f, 1f,
                                   Mathf.InverseLerp(5f, maxSpeed, speed));

            carRb.AddTorque(
                -transform.up * localAngularVelocity.y * yawDamping,
                ForceMode.Acceleration);

            float alignScale = Mathf.Lerp(1f, 0.25f, driftAmount * Mathf.Abs(steerInput));
            float speedScale = Mathf.InverseLerp(5f, 30f, speed);
            carRb.AddTorque(Vector3.up * slipAngle * Mathf.Deg2Rad * alignStrength * alignScale * speedScale,
                            ForceMode.Acceleration);
        }

        void AnimateWheels()
        {
            foreach (Wheel wheel in wheels)
            {
                if (wheel.axel == Axel.Front)
                {
                    if (wheel.wheelCollider == null ||
                    wheel.wheelModel == null) continue;

                    wheel.wheelCollider.GetWorldPose(
                        out Vector3 position,
                        out Quaternion rotation);

                    wheel.wheelModel.transform.SetPositionAndRotation(
                        position, rotation);
                }
            }
        }

        [Header("Skid Marks")]
        public float skidStartSlip = 0.6f;    // slip needed to START leaving a mark
        public float skidStopSlip = 0.3f;     // slip must fall below this to STOP
        public float skidHoldTime = 0.25f;    // seconds marks keep going after slip drops
        public float skidMinSpeed = 8f;       // km/h
        public bool skidFrontWheelsToo = false;
        public bool debugSkidSlip = false;

        float[] skidTimer;
        bool[] skidOn;

        void WheelEffects()
        {
            if (skidTimer == null || skidTimer.Length != wheels.Count)
            {
                skidTimer = new float[wheels.Count];
                skidOn = new bool[wheels.Count];
            }

            float speed = carRb.linearVelocity.magnitude * 3.6f;

            for (int i = 0; i < wheels.Count; i++)
            {
                Wheel wheel = wheels[i];
                if (wheel.trailRenderer == null || wheel.wheelCollider == null) continue;

                bool allowed = skidFrontWheelsToo || wheel.axel == Axel.Rear;
                float slip = 0f;
                bool grounded = wheel.wheelCollider.GetGroundHit(out WheelHit hit);

                if (grounded && allowed && speed > skidMinSpeed)
                    slip = Mathf.Max(Mathf.Abs(hit.sidewaysSlip), Mathf.Abs(hit.forwardSlip));

                if (debugSkidSlip && allowed && grounded)
                    Debug.Log($"{wheel.wheelCollider.name} slip={slip:F2}");

                // Hysteresis: needs a higher value to start than to keep going
                if (slip > skidStartSlip || (skidOn[i] && slip > skidStopSlip))
                {
                    skidOn[i] = true;
                    skidTimer[i] = skidHoldTime;
                }
                else
                {
                    skidTimer[i] -= Time.deltaTime;
                    if (skidTimer[i] <= 0f) skidOn[i] = false;
                }

                wheel.trailRenderer.emitting = skidOn[i] && grounded;
            }
        }
    }
    }
   